//go:build windows
// +build windows

package wrappedreadline

// getWidth impl for other
func getWidth() int {
	return 0
}
