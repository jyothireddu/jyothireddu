// Package plugingetter defines means to download and install plugins.
package plugingetter
