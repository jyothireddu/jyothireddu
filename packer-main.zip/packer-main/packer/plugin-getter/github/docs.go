// Package github defines a Github getter.

package github
