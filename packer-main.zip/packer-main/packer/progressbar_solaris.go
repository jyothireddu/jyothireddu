package packer

import (
	packersdk "github.com/hashicorp/packer-plugin-sdk/packer"
)

type UiProgressBar = packersdk.NoopProgressTracker
