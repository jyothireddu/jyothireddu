//go:build windows
// +build windows

package command

const (
	defaultConfigDir = "packer.d"
)
