package env

const (
	HCPClientID               = "HCP_CLIENT_ID"
	HCPClientSecret           = "HCP_CLIENT_SECRET"
	HCPPackerRegistry         = "HCP_PACKER_REGISTRY"
	HCPPackerBucket           = "HCP_PACKER_BUCKET_NAME"
	HCPPackerBuildFingerprint = "HCP_PACKER_BUILD_FINGERPRINT"
)
